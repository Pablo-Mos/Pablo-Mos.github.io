Run the program normally and when prompted with window for user input, enter any number, press enter, and see new trees generated from that random seed.

Default packages were used.