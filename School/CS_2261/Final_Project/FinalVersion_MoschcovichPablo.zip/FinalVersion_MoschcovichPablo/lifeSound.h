// lifeSound sound made by wav2c

extern const unsigned int lifeSound_sampleRate;
extern const unsigned int lifeSound_length;
extern const signed char lifeSound_data[];
