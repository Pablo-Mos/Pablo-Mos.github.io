// rowClearSound sound made by wav2c

extern const unsigned int rowClearSound_sampleRate;
extern const unsigned int rowClearSound_length;
extern const signed char rowClearSound_data[];
