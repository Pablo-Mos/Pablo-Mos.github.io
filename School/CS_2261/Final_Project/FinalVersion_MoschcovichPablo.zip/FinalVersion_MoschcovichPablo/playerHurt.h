// playerHurt sound made by wav2c

extern const unsigned int playerHurt_sampleRate;
extern const unsigned int playerHurt_length;
extern const signed char playerHurt_data[];
