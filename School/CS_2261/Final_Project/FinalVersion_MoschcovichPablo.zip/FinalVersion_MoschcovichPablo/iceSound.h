// iceSound sound made by wav2c

extern const unsigned int iceSound_sampleRate;
extern const unsigned int iceSound_length;
extern const signed char iceSound_data[];
