// ammoSound sound made by wav2c

extern const unsigned int ammoSound_sampleRate;
extern const unsigned int ammoSound_length;
extern const signed char ammoSound_data[];
