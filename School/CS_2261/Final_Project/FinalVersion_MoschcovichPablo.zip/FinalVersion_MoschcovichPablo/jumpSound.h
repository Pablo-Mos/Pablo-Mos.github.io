// jumpSound sound made by wav2c

extern const unsigned int jumpSound_sampleRate;
extern const unsigned int jumpSound_length;
extern const signed char jumpSound_data[];
