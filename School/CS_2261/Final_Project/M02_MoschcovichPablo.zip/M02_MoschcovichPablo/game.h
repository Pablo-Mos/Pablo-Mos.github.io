// extern int timer;

// game prototypes
void initGame();
void updateGame();
void drawGame();