﻿// WarmUp 2
//
// Pablo Moschcovich

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateMesh : MonoBehaviour {

	private Vector3[] verts;  // the vertices of the mesh
	private int[] tris;       // the triangles of the mesh (triplets of integer references to vertices)
	private int ntris = 0;    // the number of triangles that have been created so far
	public int rs = 0;

	// Create a mesh and put multiple copies of it into the scene.

	void Start() {
		// call the routine that makes a mesh from scratch
		Mesh my_mesh = CreateMyMesh();

		// make multiple copies of this mesh and place these copies in the scene

		float k = 10.0f;
		int num_objects = 40;
		Random.seed = rs;
		for (int i = 0; i < num_objects; i++) {

			// create a new GameObject and give it a MeshFilter and a MeshRenderer
			GameObject s = new GameObject(i.ToString("Object 0"));
			s.AddComponent<MeshFilter>();
			s.AddComponent<MeshRenderer>();

			float t = i / (float) num_objects;    // t in range [0,1]
			float x = k * (2 * t - 1);            // x translate in range of [-k,k]
			float y = Random.value*1.0f;
			float z = Random.value*1.0f;
			s.transform.position = new Vector3 (x, y, z);  // move this object to a new location
			s.transform.localScale = new Vector3 (0.25f, 0.25f, 0.25f);  // shrink the object

			// associate my mesh with this object
			s.GetComponent<MeshFilter>().mesh = my_mesh;

			// change the color of the object
			Renderer rend = s.GetComponent<Renderer>();
			rend.material.color = new Color (Random.value, Random.value, Random.value, 1.0f);  // random color
		}
	
	}

	// Create a pyramid

	Mesh CreateMyMesh() {
		
		// create a mesh object
		Mesh mesh = new Mesh();

		// vertices of a pyramid
		int num_verts = 5;
		verts = new Vector3[num_verts];

		// vertices for faces of the pyramid

		verts[0] = new Vector3 ( 1, -1, -1);
		verts[1] = new Vector3 ( 1, -1,  1);
		verts[2] = new Vector3 (-1, -1,  1);
		verts[3] = new Vector3 (-1, -1, -1);
		
		verts[4] = new Vector3 (0,  1, 0);

		int num_tris = 6;  // need 6 triangles in total
		tris = new int[num_tris * 3];  // need 3 vertices per triangle

		MakeQuad (0, 1, 2, 3);
	
		MakeTri(4,1,0);
		MakeTri(4,2,1);
		MakeTri(4,3,2);
		MakeTri(4,0,3);



		// save the vertices and triangles in the mesh object
		mesh.vertices = verts;
		mesh.triangles = tris;

		mesh.RecalculateNormals();  // automatically calculate the vertex normals

		return (mesh);
	}

	// make a triangle from three vertex indices (clockwise order)
	void MakeTri(int i1, int i2, int i3) {
		int index = ntris * 3;  // figure out the base index for storing triangle indices
		ntris++;

		tris[index]     = i1;
		tris[index + 1] = i2;
		tris[index + 2] = i3;
	}

	// make a quadrilateral from four vertex indices (clockwise order)
	void MakeQuad(int i1, int i2, int i3, int i4) {
		MakeTri (i1, i2, i3);
		MakeTri (i1, i3, i4);
	}

	// Update is called once per frame
	void Update () {
		
	}
}
