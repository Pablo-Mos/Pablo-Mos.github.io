// enemyHit sound made by wav2c

extern const unsigned int enemyHit_sampleRate;
extern const unsigned int enemyHit_length;
extern const signed char enemyHit_data[];
